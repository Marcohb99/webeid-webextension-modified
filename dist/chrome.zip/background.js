(function () {
  'use strict';

  (function (global, factory) {
    if (typeof define === "function" && define.amd) {
      define("webextension-polyfill", ["module"], factory);
    } else if (typeof exports !== "undefined") {
      factory(module);
    } else {
      var mod = {
        exports: {}
      };
      factory(mod);
      global.browser = mod.exports;
    }
  })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : window, function (module) {

    if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
      const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
      const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)"; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
      // optimization for Firefox. Since Spidermonkey does not fully parse the
      // contents of a function until the first time it's called, and since it will
      // never actually need to be called, this allows the polyfill to be included
      // in Firefox nearly for free.

      const wrapAPIs = extensionAPIs => {
        // NOTE: apiMetadata is associated to the content of the api-metadata.json file
        // at build time by replacing the following "include" with the content of the
        // JSON file.
        const apiMetadata = {
          "alarms": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "clearAll": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getAll": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "bookmarks": {
            "create": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "get": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getChildren": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getRecent": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getSubTree": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getTree": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "move": {
              "minArgs": 2,
              "maxArgs": 2
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeTree": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "search": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "update": {
              "minArgs": 2,
              "maxArgs": 2
            }
          },
          "browserAction": {
            "disable": {
              "minArgs": 0,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "enable": {
              "minArgs": 0,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "getBadgeBackgroundColor": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getBadgeText": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getPopup": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getTitle": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "openPopup": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "setBadgeBackgroundColor": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "setBadgeText": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "setIcon": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "setPopup": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "setTitle": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            }
          },
          "browsingData": {
            "remove": {
              "minArgs": 2,
              "maxArgs": 2
            },
            "removeCache": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeCookies": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeDownloads": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeFormData": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeHistory": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeLocalStorage": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removePasswords": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removePluginData": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "settings": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "commands": {
            "getAll": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "contextMenus": {
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeAll": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "update": {
              "minArgs": 2,
              "maxArgs": 2
            }
          },
          "cookies": {
            "get": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getAll": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getAllCookieStores": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "devtools": {
            "inspectedWindow": {
              "eval": {
                "minArgs": 1,
                "maxArgs": 2,
                "singleCallbackArg": false
              }
            },
            "panels": {
              "create": {
                "minArgs": 3,
                "maxArgs": 3,
                "singleCallbackArg": true
              }
            }
          },
          "downloads": {
            "cancel": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "download": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "erase": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getFileIcon": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "open": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "pause": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeFile": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "resume": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "search": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "show": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            }
          },
          "extension": {
            "isAllowedFileSchemeAccess": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "isAllowedIncognitoAccess": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "history": {
            "addUrl": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "deleteAll": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "deleteRange": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "deleteUrl": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getVisits": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "search": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "i18n": {
            "detectLanguage": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getAcceptLanguages": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "identity": {
            "launchWebAuthFlow": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "idle": {
            "queryState": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "management": {
            "get": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getAll": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "getSelf": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "setEnabled": {
              "minArgs": 2,
              "maxArgs": 2
            },
            "uninstallSelf": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "notifications": {
            "clear": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "create": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "getAll": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "getPermissionLevel": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "update": {
              "minArgs": 2,
              "maxArgs": 2
            }
          },
          "pageAction": {
            "getPopup": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getTitle": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "hide": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "setIcon": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "setPopup": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "setTitle": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            },
            "show": {
              "minArgs": 1,
              "maxArgs": 1,
              "fallbackToNoCallback": true
            }
          },
          "permissions": {
            "contains": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getAll": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "request": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "runtime": {
            "getBackgroundPage": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "getPlatformInfo": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "openOptionsPage": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "requestUpdateCheck": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "sendMessage": {
              "minArgs": 1,
              "maxArgs": 3
            },
            "sendNativeMessage": {
              "minArgs": 2,
              "maxArgs": 2
            },
            "setUninstallURL": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "sessions": {
            "getDevices": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getRecentlyClosed": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "restore": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "storage": {
            "local": {
              "clear": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getBytesInUse": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "set": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "managed": {
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getBytesInUse": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "sync": {
              "clear": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getBytesInUse": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "set": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          },
          "tabs": {
            "captureVisibleTab": {
              "minArgs": 0,
              "maxArgs": 2
            },
            "create": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "detectLanguage": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "discard": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "duplicate": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "executeScript": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "get": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getCurrent": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "getZoom": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getZoomSettings": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "highlight": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "insertCSS": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "move": {
              "minArgs": 2,
              "maxArgs": 2
            },
            "query": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "reload": {
              "minArgs": 0,
              "maxArgs": 2
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "removeCSS": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "sendMessage": {
              "minArgs": 2,
              "maxArgs": 3
            },
            "setZoom": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "setZoomSettings": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "update": {
              "minArgs": 1,
              "maxArgs": 2
            }
          },
          "topSites": {
            "get": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "webNavigation": {
            "getAllFrames": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "getFrame": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "webRequest": {
            "handlerBehaviorChanged": {
              "minArgs": 0,
              "maxArgs": 0
            }
          },
          "windows": {
            "create": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "get": {
              "minArgs": 1,
              "maxArgs": 2
            },
            "getAll": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getCurrent": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getLastFocused": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "update": {
              "minArgs": 2,
              "maxArgs": 2
            }
          }
        };

        if (Object.keys(apiMetadata).length === 0) {
          throw new Error("api-metadata.json has not been included in browser-polyfill");
        }
        /**
         * A WeakMap subclass which creates and stores a value for any key which does
         * not exist when accessed, but behaves exactly as an ordinary WeakMap
         * otherwise.
         *
         * @param {function} createItem
         *        A function which will be called in order to create the value for any
         *        key which does not exist, the first time it is accessed. The
         *        function receives, as its only argument, the key being created.
         */


        class DefaultWeakMap extends WeakMap {
          constructor(createItem, items = undefined) {
            super(items);
            this.createItem = createItem;
          }

          get(key) {
            if (!this.has(key)) {
              this.set(key, this.createItem(key));
            }

            return super.get(key);
          }

        }
        /**
         * Returns true if the given object is an object with a `then` method, and can
         * therefore be assumed to behave as a Promise.
         *
         * @param {*} value The value to test.
         * @returns {boolean} True if the value is thenable.
         */


        const isThenable = value => {
          return value && typeof value === "object" && typeof value.then === "function";
        };
        /**
         * Creates and returns a function which, when called, will resolve or reject
         * the given promise based on how it is called:
         *
         * - If, when called, `chrome.runtime.lastError` contains a non-null object,
         *   the promise is rejected with that value.
         * - If the function is called with exactly one argument, the promise is
         *   resolved to that value.
         * - Otherwise, the promise is resolved to an array containing all of the
         *   function's arguments.
         *
         * @param {object} promise
         *        An object containing the resolution and rejection functions of a
         *        promise.
         * @param {function} promise.resolve
         *        The promise's resolution function.
         * @param {function} promise.rejection
         *        The promise's rejection function.
         * @param {object} metadata
         *        Metadata about the wrapped method which has created the callback.
         * @param {integer} metadata.maxResolvedArgs
         *        The maximum number of arguments which may be passed to the
         *        callback created by the wrapped async function.
         *
         * @returns {function}
         *        The generated callback function.
         */


        const makeCallback = (promise, metadata) => {
          return (...callbackArgs) => {
            if (extensionAPIs.runtime.lastError) {
              promise.reject(extensionAPIs.runtime.lastError);
            } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
              promise.resolve(callbackArgs[0]);
            } else {
              promise.resolve(callbackArgs);
            }
          };
        };

        const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
        /**
         * Creates a wrapper function for a method with the given name and metadata.
         *
         * @param {string} name
         *        The name of the method which is being wrapped.
         * @param {object} metadata
         *        Metadata about the method being wrapped.
         * @param {integer} metadata.minArgs
         *        The minimum number of arguments which must be passed to the
         *        function. If called with fewer than this number of arguments, the
         *        wrapper will raise an exception.
         * @param {integer} metadata.maxArgs
         *        The maximum number of arguments which may be passed to the
         *        function. If called with more than this number of arguments, the
         *        wrapper will raise an exception.
         * @param {integer} metadata.maxResolvedArgs
         *        The maximum number of arguments which may be passed to the
         *        callback created by the wrapped async function.
         *
         * @returns {function(object, ...*)}
         *       The generated wrapper function.
         */


        const wrapAsyncFunction = (name, metadata) => {
          return function asyncFunctionWrapper(target, ...args) {
            if (args.length < metadata.minArgs) {
              throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
            }

            if (args.length > metadata.maxArgs) {
              throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
            }

            return new Promise((resolve, reject) => {
              if (metadata.fallbackToNoCallback) {
                // This API method has currently no callback on Chrome, but it return a promise on Firefox,
                // and so the polyfill will try to call it with a callback first, and it will fallback
                // to not passing the callback if the first call fails.
                try {
                  target[name](...args, makeCallback({
                    resolve,
                    reject
                  }, metadata));
                } catch (cbError) {
                  console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                  target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                  // use the unsupported callback anymore.

                  metadata.fallbackToNoCallback = false;
                  metadata.noCallback = true;
                  resolve();
                }
              } else if (metadata.noCallback) {
                target[name](...args);
                resolve();
              } else {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              }
            });
          };
        };
        /**
         * Wraps an existing method of the target object, so that calls to it are
         * intercepted by the given wrapper function. The wrapper function receives,
         * as its first argument, the original `target` object, followed by each of
         * the arguments passed to the original method.
         *
         * @param {object} target
         *        The original target object that the wrapped method belongs to.
         * @param {function} method
         *        The method being wrapped. This is used as the target of the Proxy
         *        object which is created to wrap the method.
         * @param {function} wrapper
         *        The wrapper function which is called in place of a direct invocation
         *        of the wrapped method.
         *
         * @returns {Proxy<function>}
         *        A Proxy object for the given method, which invokes the given wrapper
         *        method in its place.
         */


        const wrapMethod = (target, method, wrapper) => {
          return new Proxy(method, {
            apply(targetMethod, thisObj, args) {
              return wrapper.call(thisObj, target, ...args);
            }

          });
        };

        let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
        /**
         * Wraps an object in a Proxy which intercepts and wraps certain methods
         * based on the given `wrappers` and `metadata` objects.
         *
         * @param {object} target
         *        The target object to wrap.
         *
         * @param {object} [wrappers = {}]
         *        An object tree containing wrapper functions for special cases. Any
         *        function present in this object tree is called in place of the
         *        method in the same location in the `target` object tree. These
         *        wrapper methods are invoked as described in {@see wrapMethod}.
         *
         * @param {object} [metadata = {}]
         *        An object tree containing metadata used to automatically generate
         *        Promise-based wrapper functions for asynchronous. Any function in
         *        the `target` object tree which has a corresponding metadata object
         *        in the same location in the `metadata` tree is replaced with an
         *        automatically-generated wrapper function, as described in
         *        {@see wrapAsyncFunction}
         *
         * @returns {Proxy<object>}
         */

        const wrapObject = (target, wrappers = {}, metadata = {}) => {
          let cache = Object.create(null);
          let handlers = {
            has(proxyTarget, prop) {
              return prop in target || prop in cache;
            },

            get(proxyTarget, prop, receiver) {
              if (prop in cache) {
                return cache[prop];
              }

              if (!(prop in target)) {
                return undefined;
              }

              let value = target[prop];

              if (typeof value === "function") {
                // This is a method on the underlying object. Check if we need to do
                // any wrapping.
                if (typeof wrappers[prop] === "function") {
                  // We have a special-case wrapper for this method.
                  value = wrapMethod(target, target[prop], wrappers[prop]);
                } else if (hasOwnProperty(metadata, prop)) {
                  // This is an async method that we have metadata for. Create a
                  // Promise wrapper for it.
                  let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                  value = wrapMethod(target, target[prop], wrapper);
                } else {
                  // This is a method that we don't know or care about. Return the
                  // original method, bound to the underlying object.
                  value = value.bind(target);
                }
              } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                // This is an object that we need to do some wrapping for the children
                // of. Create a sub-object wrapper for it with the appropriate child
                // metadata.
                value = wrapObject(value, wrappers[prop], metadata[prop]);
              } else if (hasOwnProperty(metadata, "*")) {
                // Wrap all properties in * namespace.
                value = wrapObject(value, wrappers[prop], metadata["*"]);
              } else {
                // We don't need to do any wrapping for this property,
                // so just forward all access to the underlying object.
                Object.defineProperty(cache, prop, {
                  configurable: true,
                  enumerable: true,

                  get() {
                    return target[prop];
                  },

                  set(value) {
                    target[prop] = value;
                  }

                });
                return value;
              }

              cache[prop] = value;
              return value;
            },

            set(proxyTarget, prop, value, receiver) {
              if (prop in cache) {
                cache[prop] = value;
              } else {
                target[prop] = value;
              }

              return true;
            },

            defineProperty(proxyTarget, prop, desc) {
              return Reflect.defineProperty(cache, prop, desc);
            },

            deleteProperty(proxyTarget, prop) {
              return Reflect.deleteProperty(cache, prop);
            }

          }; // Per contract of the Proxy API, the "get" proxy handler must return the
          // original value of the target if that value is declared read-only and
          // non-configurable. For this reason, we create an object with the
          // prototype set to `target` instead of using `target` directly.
          // Otherwise we cannot return a custom object for APIs that
          // are declared read-only and non-configurable, such as `chrome.devtools`.
          //
          // The proxy handlers themselves will still use the original `target`
          // instead of the `proxyTarget`, so that the methods and properties are
          // dereferenced via the original targets.

          let proxyTarget = Object.create(target);
          return new Proxy(proxyTarget, handlers);
        };
        /**
         * Creates a set of wrapper functions for an event object, which handles
         * wrapping of listener functions that those messages are passed.
         *
         * A single wrapper is created for each listener function, and stored in a
         * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
         * retrieve the original wrapper, so that  attempts to remove a
         * previously-added listener work as expected.
         *
         * @param {DefaultWeakMap<function, function>} wrapperMap
         *        A DefaultWeakMap object which will create the appropriate wrapper
         *        for a given listener function when one does not exist, and retrieve
         *        an existing one when it does.
         *
         * @returns {object}
         */


        const wrapEvent = wrapperMap => ({
          addListener(target, listener, ...args) {
            target.addListener(wrapperMap.get(listener), ...args);
          },

          hasListener(target, listener) {
            return target.hasListener(wrapperMap.get(listener));
          },

          removeListener(target, listener) {
            target.removeListener(wrapperMap.get(listener));
          }

        }); // Keep track if the deprecation warning has been logged at least once.


        let loggedSendResponseDeprecationWarning = false;
        const onMessageWrappers = new DefaultWeakMap(listener => {
          if (typeof listener !== "function") {
            return listener;
          }
          /**
           * Wraps a message listener function so that it may send responses based on
           * its return value, rather than by returning a sentinel value and calling a
           * callback. If the listener function returns a Promise, the response is
           * sent when the promise either resolves or rejects.
           *
           * @param {*} message
           *        The message sent by the other end of the channel.
           * @param {object} sender
           *        Details about the sender of the message.
           * @param {function(*)} sendResponse
           *        A callback which, when called with an arbitrary argument, sends
           *        that value as a response.
           * @returns {boolean}
           *        True if the wrapped listener returned a Promise, which will later
           *        yield a response. False otherwise.
           */


          return function onMessage(message, sender, sendResponse) {
            let didCallSendResponse = false;
            let wrappedSendResponse;
            let sendResponsePromise = new Promise(resolve => {
              wrappedSendResponse = function (response) {
                if (!loggedSendResponseDeprecationWarning) {
                  console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                  loggedSendResponseDeprecationWarning = true;
                }

                didCallSendResponse = true;
                resolve(response);
              };
            });
            let result;

            try {
              result = listener(message, sender, wrappedSendResponse);
            } catch (err) {
              result = Promise.reject(err);
            }

            const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
            // wrappedSendResponse synchronously, we can exit earlier
            // because there will be no response sent from this listener.

            if (result !== true && !isResultThenable && !didCallSendResponse) {
              return false;
            } // A small helper to send the message if the promise resolves
            // and an error if the promise rejects (a wrapped sendMessage has
            // to translate the message into a resolved promise or a rejected
            // promise).


            const sendPromisedResult = promise => {
              promise.then(msg => {
                // send the message value.
                sendResponse(msg);
              }, error => {
                // Send a JSON representation of the error if the rejected value
                // is an instance of error, or the object itself otherwise.
                let message;

                if (error && (error instanceof Error || typeof error.message === "string")) {
                  message = error.message;
                } else {
                  message = "An unexpected error occurred";
                }

                sendResponse({
                  __mozWebExtensionPolyfillReject__: true,
                  message
                });
              }).catch(err => {
                // Print an error on the console if unable to send the response.
                console.error("Failed to send onMessage rejected reply", err);
              });
            }; // If the listener returned a Promise, send the resolved value as a
            // result, otherwise wait the promise related to the wrappedSendResponse
            // callback to resolve and send it as a response.


            if (isResultThenable) {
              sendPromisedResult(result);
            } else {
              sendPromisedResult(sendResponsePromise);
            } // Let Chrome know that the listener is replying.


            return true;
          };
        });

        const wrappedSendMessageCallback = ({
          reject,
          resolve
        }, reply) => {
          if (extensionAPIs.runtime.lastError) {
            // Detect when none of the listeners replied to the sendMessage call and resolve
            // the promise to undefined as in Firefox.
            // See https://github.com/mozilla/webextension-polyfill/issues/130
            if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
              resolve();
            } else {
              reject(extensionAPIs.runtime.lastError);
            }
          } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
            // Convert back the JSON representation of the error into
            // an Error instance.
            reject(new Error(reply.message));
          } else {
            resolve(reply);
          }
        };

        const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            const wrappedCb = wrappedSendMessageCallback.bind(null, {
              resolve,
              reject
            });
            args.push(wrappedCb);
            apiNamespaceObj.sendMessage(...args);
          });
        };

        const staticWrappers = {
          runtime: {
            onMessage: wrapEvent(onMessageWrappers),
            onMessageExternal: wrapEvent(onMessageWrappers),
            sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
              minArgs: 1,
              maxArgs: 3
            })
          },
          tabs: {
            sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
              minArgs: 2,
              maxArgs: 3
            })
          }
        };
        const settingMetadata = {
          clear: {
            minArgs: 1,
            maxArgs: 1
          },
          get: {
            minArgs: 1,
            maxArgs: 1
          },
          set: {
            minArgs: 1,
            maxArgs: 1
          }
        };
        apiMetadata.privacy = {
          network: {
            "*": settingMetadata
          },
          services: {
            "*": settingMetadata
          },
          websites: {
            "*": settingMetadata
          }
        };
        return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
      };

      if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
        throw new Error("This script should only be loaded in a browser extension.");
      } // The build process adds a UMD wrapper around this file, which makes the
      // `module` variable available.


      module.exports = wrapAPIs(chrome);
    } else {
      module.exports = browser;
    }
  });

  var Action;
  (function (Action) {
      Action["STATUS"] = "web-eid:status";
      Action["STATUS_ACK"] = "web-eid:status-ack";
      Action["STATUS_SUCCESS"] = "web-eid:status-success";
      Action["STATUS_FAILURE"] = "web-eid:status-failure";
      Action["AUTHENTICATE"] = "web-eid:authenticate";
      Action["AUTHENTICATE_ACK"] = "web-eid:authenticate-ack";
      Action["AUTHENTICATE_SUCCESS"] = "web-eid:authenticate-success";
      Action["AUTHENTICATE_FAILURE"] = "web-eid:authenticate-failure";
      Action["SIGN"] = "web-eid:sign";
      Action["SIGN_ACK"] = "web-eid:sign-ack";
      Action["SIGN_SUCCESS"] = "web-eid:sign-success";
      Action["SIGN_FAILURE"] = "web-eid:sign-failure";
  })(Action || (Action = {}));
  var Action$1 = Action;

  var libraryConfig = Object.freeze({
      VERSION: "0.9.0",
      EXTENSION_HANDSHAKE_TIMEOUT: 1000,
      NATIVE_APP_HANDSHAKE_TIMEOUT: 5 * 1000,
      DEFAULT_USER_INTERACTION_TIMEOUT: 2 * 60 * 1000,
      DEFAULT_SERVER_REQUEST_TIMEOUT: 20 * 1000,
  });

  var ErrorCode;
  (function (ErrorCode) {
      // Timeout errors
      ErrorCode["ERR_WEBEID_ACTION_TIMEOUT"] = "ERR_WEBEID_ACTION_TIMEOUT";
      ErrorCode["ERR_WEBEID_USER_TIMEOUT"] = "ERR_WEBEID_USER_TIMEOUT";
      ErrorCode["ERR_WEBEID_SERVER_TIMEOUT"] = "ERR_WEBEID_SERVER_TIMEOUT";
      // Health errors
      ErrorCode["ERR_WEBEID_VERSION_MISMATCH"] = "ERR_WEBEID_VERSION_MISMATCH";
      ErrorCode["ERR_WEBEID_VERSION_INVALID"] = "ERR_WEBEID_VERSION_INVALID";
      ErrorCode["ERR_WEBEID_EXTENSION_UNAVAILABLE"] = "ERR_WEBEID_EXTENSION_UNAVAILABLE";
      ErrorCode["ERR_WEBEID_NATIVE_UNAVAILABLE"] = "ERR_WEBEID_NATIVE_UNAVAILABLE";
      ErrorCode["ERR_WEBEID_UNKNOWN_ERROR"] = "ERR_WEBEID_UNKNOWN_ERROR";
      // Security errors
      ErrorCode["ERR_WEBEID_CONTEXT_INSECURE"] = "ERR_WEBEID_CONTEXT_INSECURE";
      ErrorCode["ERR_WEBEID_PROTOCOL_INSECURE"] = "ERR_WEBEID_PROTOCOL_INSECURE";
      ErrorCode["ERR_WEBEID_TLS_CONNECTION_BROKEN"] = "ERR_WEBEID_TLS_CONNECTION_BROKEN";
      ErrorCode["ERR_WEBEID_TLS_CONNECTION_INSECURE"] = "ERR_WEBEID_TLS_CONNECTION_INSECURE";
      ErrorCode["ERR_WEBEID_TLS_CONNECTION_WEAK"] = "ERR_WEBEID_TLS_CONNECTION_WEAK";
      ErrorCode["ERR_WEBEID_CERTIFICATE_CHANGED"] = "ERR_WEBEID_CERTIFICATE_CHANGED";
      ErrorCode["ERR_WEBEID_ORIGIN_MISMATCH"] = "ERR_WEBEID_ORIGIN_MISMATCH";
      // Third party errors
      ErrorCode["ERR_WEBEID_SERVER_REJECTED"] = "ERR_WEBEID_SERVER_REJECTED";
      ErrorCode["ERR_WEBEID_USER_CANCELLED"] = "ERR_WEBEID_USER_CANCELLED";
      ErrorCode["ERR_WEBEID_NATIVE_FATAL"] = "ERR_WEBEID_NATIVE_FATAL";
      // Developer mistakes
      ErrorCode["ERR_WEBEID_ACTION_PENDING"] = "ERR_WEBEID_ACTION_PENDING";
      ErrorCode["ERR_WEBEID_MISSING_PARAMETER"] = "ERR_WEBEID_MISSING_PARAMETER";
  })(ErrorCode || (ErrorCode = {}));
  var ErrorCode$1 = ErrorCode;

  class ProtocolInsecureError extends Error {
      constructor(message = "HTTPS required") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_PROTOCOL_INSECURE;
      }
  }

  class UserTimeoutError extends Error {
      constructor(message = "user failed to respond in time") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_USER_TIMEOUT;
      }
  }

  class ServerTimeoutError extends Error {
      constructor(message = "server failed to respond in time") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_SERVER_TIMEOUT;
      }
  }

  class OriginMismatchError extends Error {
      constructor(message = "URLs for a single operation require the same origin") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_ORIGIN_MISMATCH;
      }
  }

  class CertificateChangedError extends Error {
      constructor(message = "server certificate changed between requests") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_CERTIFICATE_CHANGED;
      }
  }

  const SECURE_CONTEXTS_INFO_URL = "https://developer.mozilla.org/en-US/docs/Web/Security/Secure_Contexts";
  class ContextInsecureError extends Error {
      constructor(message = "Secure context required, see " + SECURE_CONTEXTS_INFO_URL) {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_CONTEXT_INSECURE;
      }
  }

  class ExtensionUnavailableError extends Error {
      constructor(message = "Web-eID extension is not available") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_EXTENSION_UNAVAILABLE;
      }
  }

  class ActionPendingError extends Error {
      constructor(message = "same action for Web-eID browser extension is already pending") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_ACTION_PENDING;
      }
  }

  class NativeFatalError extends Error {
      constructor(message = "native application terminated with a fatal error") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_NATIVE_FATAL;
      }
  }

  class NativeUnavailableError extends Error {
      constructor(message = "Web-eID native application is not available") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_NATIVE_UNAVAILABLE;
      }
  }

  class ServerRejectedError extends Error {
      constructor(message = "server rejected the request") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_SERVER_REJECTED;
      }
  }

  class UserCancelledError extends Error {
      constructor(message = "request was cancelled by the user") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_USER_CANCELLED;
      }
  }

  function tmpl(strings, requiresUpdate) {
      return `Update required for Web-eID ${requiresUpdate}`;
  }
  class VersionMismatchError extends Error {
      constructor(message, versions, requiresUpdate) {
          if (!message) {
              if (!requiresUpdate) {
                  message = "requiresUpdate not provided";
              }
              else if (requiresUpdate.extension && requiresUpdate.nativeApp) {
                  message = tmpl `${"extension and native app"}`;
              }
              else if (requiresUpdate.extension) {
                  message = tmpl `${"extension"}`;
              }
              else if (requiresUpdate.nativeApp) {
                  message = tmpl `${"native app"}`;
              }
          }
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_VERSION_MISMATCH;
          this.requiresUpdate = requiresUpdate;
          if (versions) {
              const { library, extension, nativeApp } = versions;
              Object.assign(this, { library, extension, nativeApp });
          }
      }
  }

  class TlsConnectionBrokenError extends Error {
      constructor(message = "TLS connection was broken") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_TLS_CONNECTION_BROKEN;
      }
  }

  class TlsConnectionInsecureError extends Error {
      constructor(message = "TLS connection was insecure") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_TLS_CONNECTION_INSECURE;
      }
  }

  class TlsConnectionWeakError extends Error {
      constructor(message = "TLS connection was weak") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_TLS_CONNECTION_WEAK;
      }
  }

  class ActionTimeoutError extends Error {
      constructor(message = "extension message timeout") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_ACTION_TIMEOUT;
      }
  }

  class VersionInvalidError extends Error {
      constructor(message = "invalid version string") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_VERSION_INVALID;
      }
  }

  class UnknownError extends Error {
      constructor(message = "an unknown error occurred") {
          super(message);
          this.name = this.constructor.name;
          this.code = ErrorCode$1.ERR_WEBEID_UNKNOWN_ERROR;
      }
  }

  const errorCodeToErrorClass = {
      [ErrorCode$1.ERR_WEBEID_ACTION_PENDING]: ActionPendingError,
      [ErrorCode$1.ERR_WEBEID_ACTION_TIMEOUT]: ActionTimeoutError,
      [ErrorCode$1.ERR_WEBEID_CERTIFICATE_CHANGED]: CertificateChangedError,
      [ErrorCode$1.ERR_WEBEID_ORIGIN_MISMATCH]: OriginMismatchError,
      [ErrorCode$1.ERR_WEBEID_CONTEXT_INSECURE]: ContextInsecureError,
      [ErrorCode$1.ERR_WEBEID_EXTENSION_UNAVAILABLE]: ExtensionUnavailableError,
      [ErrorCode$1.ERR_WEBEID_NATIVE_FATAL]: NativeFatalError,
      [ErrorCode$1.ERR_WEBEID_NATIVE_UNAVAILABLE]: NativeUnavailableError,
      [ErrorCode$1.ERR_WEBEID_PROTOCOL_INSECURE]: ProtocolInsecureError,
      [ErrorCode$1.ERR_WEBEID_SERVER_REJECTED]: ServerRejectedError,
      [ErrorCode$1.ERR_WEBEID_SERVER_TIMEOUT]: ServerTimeoutError,
      [ErrorCode$1.ERR_WEBEID_TLS_CONNECTION_BROKEN]: TlsConnectionBrokenError,
      [ErrorCode$1.ERR_WEBEID_TLS_CONNECTION_INSECURE]: TlsConnectionInsecureError,
      [ErrorCode$1.ERR_WEBEID_TLS_CONNECTION_WEAK]: TlsConnectionWeakError,
      [ErrorCode$1.ERR_WEBEID_USER_CANCELLED]: UserCancelledError,
      [ErrorCode$1.ERR_WEBEID_USER_TIMEOUT]: UserTimeoutError,
      [ErrorCode$1.ERR_WEBEID_VERSION_INVALID]: VersionInvalidError,
      [ErrorCode$1.ERR_WEBEID_VERSION_MISMATCH]: VersionMismatchError,
  };
  function serializeError(error) {
      const { message, name, fileName, lineNumber, columnNumber, stack, } = error;
      return {
          ...(Object.fromEntries(Object.getOwnPropertyNames(error)
              .map((prop) => [prop, error[prop]]))),
          message,
          name,
          fileName,
          lineNumber,
          columnNumber,
          stack,
      };
  }
  function deserializeError(errorObject) {
      let error;
      if (typeof errorObject.code == "string" && errorObject.code in errorCodeToErrorClass) {
          const CustomError = errorCodeToErrorClass[errorObject.code];
          error = new CustomError();
      }
      else {
          error = new UnknownError();
      }
      for (const [key, value] of Object.entries(errorObject)) {
          error[key] = value;
      }
      return error;
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  var config = Object.freeze({
      NATIVE_APP_NAME: "webeidPython",
      VERSION: "0.9.0",
      NATIVE_MESSAGE_MAX_BYTES: 8192,
      TOKEN_SIGNING_BACKWARDS_COMPATIBILITY: true,
      TOKEN_SIGNING_USER_INTERACTION_TIMEOUT: 1000 * 60 * 5,
  });

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  /**
   * Transforms the Fetch API Header object to plain JSON.stringify-able object type.
   *
   * @param headers Fetch API Headers object
   *
   * @returns The headers in a simple object, where keys and values are strings.
   *
   * @example
   *   headersToObject(fetchResponse.headers)
   *   // => {
   *   //   "connection":     "keep-alive",
   *   //   "content-length": "49",
   *   //   "content-type":   "application/json; charset=utf-8",
   *   //   "date":           "Mon, 27 Apr 2020 06:28:54 GMT",
   *   //   "etag":           "W/\"30-YHV2nUGU912eoDvI+roJ2Yqn5SA\"",
   *   //   "x-powered-by":   "Express"
   *   // }
   */
  function headersToObject(headers) {
      function reducer(acc, curr) {
          if (typeof curr[0] == "string") {
              acc[curr[0]] = curr[1];
          }
          return acc;
      }
      const headersArray = [...headers.entries()];
      const headersMap = headersArray.reduce(reducer, {});
      return headersMap;
  }
  /**
   * Creates an object composed of the picked object properties.
   *
   * @param object Object to pick from
   * @param keys   Keys to pick from the object
   *
   * @returns The new object
   *
   * @example
   *   const object = { "a": 1, "b": 2, "c": 3 };
   *   pick(object, ["a", "b"]);
   *   // => { "a": 1, "b": 2 }
   */
  function pick(object, keys) {
      return Object.keys(object)
          .filter((objectKey) => keys.includes(objectKey))
          .reduce((acc, curr) => (acc[curr] = object[curr], acc), {});
  }
  function sleep(milliseconds) {
      return new Promise((resolve) => {
          setTimeout(() => resolve(), milliseconds);
      });
  }
  async function throwAfterTimeout(milliseconds, error) {
      await sleep(milliseconds);
      throw error;
  }
  function objectByteSize(object) {
      const objectString = JSON.stringify(object);
      const objectStringBlob = new Blob([objectString]);
      return objectStringBlob.size;
  }
  function isSameOrigin(url1, url2) {
      const origin1 = new URL(url1).origin;
      const origin2 = new URL(url2).origin;
      return origin1 === origin2;
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  var NativeAppState;
  (function (NativeAppState) {
      NativeAppState[NativeAppState["UNINITIALIZED"] = 0] = "UNINITIALIZED";
      NativeAppState[NativeAppState["CONNECTING"] = 1] = "CONNECTING";
      NativeAppState[NativeAppState["CONNECTED"] = 2] = "CONNECTED";
      NativeAppState[NativeAppState["DISCONNECTED"] = 3] = "DISCONNECTED";
  })(NativeAppState || (NativeAppState = {}));
  class NativeAppService {
      constructor() {
          this.state = NativeAppState.UNINITIALIZED;
          this.port = null;
          this.pending = null;
      }
      async connect() {
          var _a;
          this.state = NativeAppState.CONNECTING;
          this.port = browser.runtime.connectNative(config.NATIVE_APP_NAME);
          this.port.onDisconnect.addListener(this.disconnectListener.bind(this));
          console.log(this.port);
          try {
              const message = await this.nextMessage(libraryConfig.NATIVE_APP_HANDSHAKE_TIMEOUT);
              if (message.version) {
                  this.state = NativeAppState.CONNECTED;
                  return message;
              }
              if (message) {
                  throw new NativeUnavailableError(`expected native application to reply with a version, got ${JSON.stringify(message)}`);
              }
              else if (this.port.error) {
                  throw new NativeUnavailableError(this.port.error.message);
              }
              else {
                  throw new NativeUnavailableError("unexpected error");
              }
          }
          catch (error) {
              if (this.port.error) {
                  console.error(this.port.error);
              }
              if (error instanceof NativeUnavailableError) {
                  throw error;
              }
              else if (error === null || error === void 0 ? void 0 : error.message) {
                  throw new NativeUnavailableError(error === null || error === void 0 ? void 0 : error.message);
              }
              else if ((_a = this.port.error) === null || _a === void 0 ? void 0 : _a.message) {
                  throw new NativeUnavailableError(this.port.error.message);
              }
              else {
                  throw new NativeUnavailableError("unexpected error");
              }
          }
      }
      disconnectListener() {
          var _a, _b, _c;
          // Accessing lastError when it exists stops chrome from throwing it unnecessarily.
          (_a = chrome === null || chrome === void 0 ? void 0 : chrome.runtime) === null || _a === void 0 ? void 0 : _a.lastError;
          this.state = NativeAppState.DISCONNECTED;
          (_c = (_b = this.pending) === null || _b === void 0 ? void 0 : _b.reject) === null || _c === void 0 ? void 0 : _c.call(_b, new UnknownError("native application closed the connection before a response"));
          this.pending = null;
      }
      close(error) {
          var _a, _b, _c;
          console.log("Disconnecting from native app");
          this.state = NativeAppState.DISCONNECTED;
          (_b = (_a = this.pending) === null || _a === void 0 ? void 0 : _a.reject) === null || _b === void 0 ? void 0 : _b.call(_a, error);
          this.pending = null;
          (_c = this.port) === null || _c === void 0 ? void 0 : _c.disconnect();
      }
      send(message) {
          switch (this.state) {
              case NativeAppState.CONNECTED: {
                  return new Promise((resolve, reject) => {
                      var _a, _b;
                      this.pending = { resolve, reject };
                      const onResponse = (message) => {
                          var _a;
                          (_a = this.port) === null || _a === void 0 ? void 0 : _a.onMessage.removeListener(onResponse);
                          if (message.error) {
                              reject(deserializeError(message.error));
                          }
                          else {
                              resolve(message);
                          }
                          this.pending = null;
                      };
                      (_a = this.port) === null || _a === void 0 ? void 0 : _a.onMessage.addListener(onResponse);
                      console.log("Sending message to native app", JSON.stringify(message));
                      const messageSize = objectByteSize(message);
                      if (messageSize > config.NATIVE_MESSAGE_MAX_BYTES) {
                          throw new Error(`native application message exceeded ${config.NATIVE_MESSAGE_MAX_BYTES} bytes`);
                      }
                      (_b = this.port) === null || _b === void 0 ? void 0 : _b.postMessage(message);
                  });
              }
              case NativeAppState.UNINITIALIZED: {
                  return Promise.reject(new Error("unable to send message, native application port is not initialized yet"));
              }
              case NativeAppState.CONNECTING: {
                  return Promise.reject(new Error("unable to send message, native application port is still connecting"));
              }
              case NativeAppState.DISCONNECTED: {
                  return Promise.reject(new Error("unable to send message, native application port is disconnected"));
              }
              default: {
                  return Promise.reject(new Error("unable to send message, unexpected native app state"));
              }
          }
      }
      nextMessage(timeout) {
          return new Promise((resolve, reject) => {
              let cleanup = null;
              let timer = null;
              const onMessageListener = (message) => {
                  cleanup === null || cleanup === void 0 ? void 0 : cleanup();
                  if (message.error) {
                      reject(deserializeError(message.error));
                  }
                  else {
                      resolve(message);
                  }
              };
              const onDisconnectListener = () => {
                  cleanup === null || cleanup === void 0 ? void 0 : cleanup();
                  reject(new NativeUnavailableError("a message from native application was expected, but native application closed connection"));
              };
              cleanup = () => {
                  var _a, _b;
                  (_a = this.port) === null || _a === void 0 ? void 0 : _a.onDisconnect.removeListener(onDisconnectListener);
                  (_b = this.port) === null || _b === void 0 ? void 0 : _b.onMessage.removeListener(onMessageListener);
                  if (timer)
                      clearTimeout(timer);
              };
              timer = setTimeout(() => {
                  cleanup === null || cleanup === void 0 ? void 0 : cleanup();
                  reject(new NativeUnavailableError(`a message from native application was expected, but message wasn't received in ${timeout}ms`));
              }, timeout);
              if (!this.port) {
                  return reject(new NativeUnavailableError("missing native application port"));
              }
              this.port.onDisconnect.addListener(onDisconnectListener);
              this.port.onMessage.addListener(onMessageListener);
          });
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  class WebServerService {
      constructor() {
          this.fingerprints = [];
      }
      hasCertificateChanged() {
          return !this.fingerprints.every((fingerprint) => this.fingerprints[0].sha256 === fingerprint.sha256);
      }
      async fetch(fetchUrl, init) {
          var _a;
          let certificateInfo;
          let fetchError = null;
          let hasWebRequestPermission = false;
          try {
              hasWebRequestPermission = await browser.permissions.contains({
                  permissions: [
                      "webRequest",
                      "webRequestBlocking",
                  ],
              });
          }
          catch (error) {
              console.log("Failed to fetch permissions", error);
          }
          certificateInfo = null;
          const onHeadersReceivedListener = async (details) => {
              const securityInfo = await browser.webRequest.getSecurityInfo(details.requestId, { rawDER: true });
              switch (securityInfo.state) {
                  case "secure": {
                      certificateInfo = securityInfo.certificates[0];
                      this.fingerprints.push(certificateInfo.fingerprint);
                      if (this.hasCertificateChanged()) {
                          fetchError = new CertificateChangedError();
                          return { cancel: true };
                      }
                      break;
                  }
                  case "broken": {
                      fetchError = new TlsConnectionBrokenError(`TLS connection was broken while requesting ${fetchUrl}`);
                      return { cancel: true };
                  }
                  case "insecure": {
                      fetchError = new TlsConnectionInsecureError(`TLS connection was insecure while requesting ${fetchUrl}`);
                      return { cancel: true };
                  }
                  case "weak": {
                      fetchError = new TlsConnectionWeakError(`TLS connection was weak while requesting ${fetchUrl}`);
                      return { cancel: true };
                  }
                  default:
                      fetchError = new Error("Unexpected connection security state");
                      return { cancel: true };
              }
          };
          if (hasWebRequestPermission) {
              browser.webRequest.onHeadersReceived.addListener(onHeadersReceivedListener, { urls: [fetchUrl] }, ["blocking"]);
          }
          try {
              const response = await fetch(fetchUrl, init);
              const headers = headersToObject(response.headers);
              const body = (((_a = headers["content-type"]) === null || _a === void 0 ? void 0 : _a.includes("application/json")) ? (await response.json())
                  : (await response.text()));
              if (hasWebRequestPermission) {
                  browser.webRequest.onHeadersReceived.removeListener(onHeadersReceivedListener);
              }
              const { ok, redirected, status, statusText, type, url, } = response;
              const result = {
                  certificateInfo,
                  ok,
                  redirected,
                  status,
                  statusText,
                  type,
                  url,
                  body,
                  headers,
              };
              if (!ok) {
                  fetchError = new ServerRejectedError();
                  Object.assign(fetchError, {
                      response: {
                          ok,
                          redirected,
                          status,
                          statusText,
                          type,
                          url,
                          body,
                          headers,
                      },
                  });
              }
              if (fetchError) {
                  throw fetchError;
              }
              return result;
          }
          finally {
              if (hasWebRequestPermission) {
                  browser.webRequest.onHeadersReceived.removeListener(onHeadersReceivedListener);
              }
          }
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  /**
   * Convert between byte array, Base64 and hexadecimal string formats.
   *
   * @example
   *  new ByteArray([ 72, 101, 108, 108, 111 ]).toBase64() // SGVsbG8=
   *  new ByteArray().fromHex("48656c6c6f").toBase64()     // SGVsbG8=
   *  new ByteArray().fromBase64("SGVsbG8=").toHex()       // 48656c6c6f
   *  new ByteArray().fromHex("48656c6c6f").valueOf()      // [72, 101, 108, 108, 111]
   */
  class ByteArray {
      constructor(byteArray) {
          this.data = byteArray || [];
      }
      fromBase64(base64) {
          this.data = atob(base64).split("").map(c => c.charCodeAt(0));
          return this;
      }
      toBase64() {
          return btoa(this.data.reduce((acc, curr) => acc += String.fromCharCode(curr), ""));
      }
      fromHex(hex) {
          const data = [];
          for (let i = 0; i < hex.length; i += 2) {
              data.push(parseInt(hex.substr(i, 2), 16));
          }
          this.data = data;
          return this;
      }
      toHex() {
          return this.data.map((byte) => ("0" + (byte & 0xFF).toString(16)).slice(-2)).join("");
      }
      valueOf() {
          return this.data;
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  async function authenticate(getAuthChallengeUrl, postAuthTokenUrl, headers, userInteractionTimeout, serverRequestTimeout) {
      var _a, _b;
      let webServerService;
      let nativeAppService;
      try {
          if (!getAuthChallengeUrl.startsWith("https:")) {
              throw new ProtocolInsecureError(`HTTPS required for getAuthChallengeUrl ${getAuthChallengeUrl}`);
          }
          if (!postAuthTokenUrl.startsWith("https:")) {
              throw new ProtocolInsecureError(`HTTPS required for postAuthTokenUrl ${postAuthTokenUrl}`);
          }
          console.log("postAuthTokenUrl: " + postAuthTokenUrl);
          if (!isSameOrigin(getAuthChallengeUrl, postAuthTokenUrl)) {
              throw new OriginMismatchError();
          }
          webServerService = new WebServerService();
          nativeAppService = new NativeAppService();
          const nativeAppStatus = await nativeAppService.connect();
          console.log("Authenticate: connected to native", nativeAppStatus);
          const response = await Promise.race([
              webServerService.fetch(getAuthChallengeUrl, {
                  headers: {
                      ...headers,
                      "Content-Type": "application/json",
                  },
              }),
              throwAfterTimeout(serverRequestTimeout, new ServerTimeoutError(`server failed to respond in time - GET ${getAuthChallengeUrl}`)),
          ]);
          console.log("Authenticate: getAuthChallengeUrl fetched");
          const token = await Promise.race([
              nativeAppService.send({
                  command: "authenticate",
                  arguments: {
                      "nonce": response.body.nonce,
                      "origin": (new URL(response.url)).origin,
                      "origin-cert": (((_a = response.certificateInfo) === null || _a === void 0 ? void 0 : _a.rawDER) ? new ByteArray((_b = response.certificateInfo) === null || _b === void 0 ? void 0 : _b.rawDER).toBase64()
                          : null),
                  },
              }),
              throwAfterTimeout(userInteractionTimeout, new UserTimeoutError()),
          ]);
          console.log("Authenticate: authentication token received");
          console.log(token);
          const tokenResponse = await Promise.race([
              webServerService.fetch(postAuthTokenUrl, {
                  method: "POST",
                  headers: {
                      ...headers,
                      "Content-Type": "application/json",
                  },
                  body: JSON.stringify(token),
              }),
              throwAfterTimeout(serverRequestTimeout, new ServerTimeoutError(`server failed to respond in time - POST ${postAuthTokenUrl}`)),
          ]);
          console.log("Authenticate: token accepted by the server");
          //BEGIN modify record entry in eID server
          const recordUrl = "https://eidrecordserver.herokuapp.com/api/eidrecords"; //remote
          // const recordUrl = "https://173dbb3a209c.ngrok.io/api/eidrecords"; //local
          console.log("Modifying record entry in the server: " + recordUrl);
          // @ts-ignore
          console.log(token["auth-token"]);
          const recordResponse = await fetch(recordUrl, {
              method: "PUT",
              headers: {
                  "Content-Type": "application/json",
                  // @ts-ignore
                  "auth-token": token["auth-token"],
                  "signature": "",
              },
              redirect: "follow",
              body: JSON.stringify({
                  "status": "Authenticate SUCCESS",
              }),
          });
          if (recordResponse.status > 300)
              throw new Error("Failed to modify record entry " + JSON.stringify(recordResponse.body));
          //END modify record entry in eID server
          return {
              action: Action$1.AUTHENTICATE_SUCCESS,
              response: {
                  ...pick(tokenResponse, [
                      "body",
                      "headers",
                      "ok",
                      "redirected",
                      "status",
                      "statusText",
                      "type",
                      "url",
                  ]),
              },
          };
      }
      catch (error) {
          console.error("Authenticate:", error);
          return {
              action: Action$1.AUTHENTICATE_FAILURE,
              error: serializeError(error),
          };
      }
      finally {
          if (nativeAppService)
              nativeAppService.close();
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  async function sign(postPrepareSigningUrl, postFinalizeSigningUrl, headers, userInteractionTimeout, serverRequestTimeout) {
      let webServerService;
      let nativeAppService;
      try {
          if (!postPrepareSigningUrl.startsWith("https:")) {
              throw new ProtocolInsecureError(`HTTPS required for postPrepareSigningUrl ${postPrepareSigningUrl}`);
          }
          if (!postFinalizeSigningUrl.startsWith("https:")) {
              throw new ProtocolInsecureError(`HTTPS required for postFinalizeSigningUrl ${postFinalizeSigningUrl}`);
          }
          if (!isSameOrigin(postPrepareSigningUrl, postFinalizeSigningUrl)) {
              throw new OriginMismatchError();
          }
          webServerService = new WebServerService();
          nativeAppService = new NativeAppService();
          let nativeAppStatus = await nativeAppService.connect();
          console.log("Sign: connected to native", nativeAppStatus);
          const certificateResponse = await Promise.race([
              nativeAppService.send({
                  command: "get-certificate",
                  arguments: {
                      "type": "sign",
                      "origin": (new URL(postPrepareSigningUrl)).origin,
                  },
              }),
              throwAfterTimeout(userInteractionTimeout, new UserTimeoutError()),
          ]);
          if (certificateResponse.error) {
              throw new Error(certificateResponse.error);
          }
          else if (!certificateResponse.certificate) {
              throw new Error("Missing signing certificate");
          }
          const { certificate } = certificateResponse;
          const supportedSignatureAlgorithms = certificateResponse["supported-signature-algos"].map((algorithmSet) => ({
              crypto: algorithmSet["crypto-algo"],
              hash: algorithmSet["hash-algo"],
              padding: algorithmSet["padding-algo"],
          }));
          const prepareDocumentResult = await Promise.race([
              webServerService.fetch(postPrepareSigningUrl, {
                  method: "POST",
                  headers: {
                      ...headers,
                      "Content-Type": "application/json",
                  },
                  body: JSON.stringify({ certificate, supportedSignatureAlgorithms }),
              }),
              throwAfterTimeout(serverRequestTimeout, new ServerTimeoutError(`server failed to respond in time - POST ${postPrepareSigningUrl}`)),
          ]);
          console.log("Sign: postPrepareSigningUrl fetched", prepareDocumentResult);
          console.log("Native app state", nativeAppService.state);
          if (nativeAppService.state === NativeAppState.CONNECTED) {
              nativeAppService.close();
          }
          nativeAppService = new NativeAppService();
          nativeAppStatus = await nativeAppService.connect();
          console.log("Sign: reconnected to native", nativeAppStatus);
          const docHash = prepareDocumentResult.body.hash;
          const signatureResponse = await Promise.race([
              nativeAppService.send({
                  command: "sign",
                  arguments: {
                      "doc-hash": docHash,
                      "hash-algo": prepareDocumentResult.body.algorithm,
                      "origin": (new URL(postPrepareSigningUrl)).origin,
                      "user-eid-cert": certificate,
                  },
              }),
              throwAfterTimeout(userInteractionTimeout, new UserTimeoutError()),
          ]);
          if (signatureResponse.error) {
              throw new Error(signatureResponse.error);
          }
          else if (!signatureResponse.signature) {
              throw new Error("Missing sign signature");
          }
          const { signature } = signatureResponse;
          const { token } = signatureResponse; //NEW for record posting
          console.log("Sign: user signature received from native app", signatureResponse);
          console.log("Sign: user signature received from native app", signature);
          console.log({
              body: JSON.stringify({
                  ...prepareDocumentResult.body,
                  signature,
              }),
          });
          const signatureVerifyResponse = await Promise.race([
              webServerService.fetch(postFinalizeSigningUrl, {
                  method: "POST",
                  headers: {
                      ...headers,
                      "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                      ...prepareDocumentResult.body,
                      signature,
                  }),
              }),
              throwAfterTimeout(serverRequestTimeout, new ServerTimeoutError(`server failed to respond in time - POST ${postFinalizeSigningUrl}`)),
          ]);
          console.log("Sign: signature accepted by the server", signatureVerifyResponse);
          //BEGIN modify record entry in eID server
          const recordUrl = "https://eidrecordserver.herokuapp.com/api/eidrecords"; //remote
          // const recordUrl = "https://173dbb3a209c.ngrok.io/api/eidrecords"; //local
          console.log("Modifying record entry in the server: " + recordUrl);
          // @ts-ignore
          console.log(token["auth-token"]);
          const recordResponse = await fetch(recordUrl, {
              method: "PUT",
              headers: {
                  "Content-Type": "application/json",
                  // @ts-ignore
                  "auth-token": token,
                  "signature": signature,
              },
              redirect: "follow",
              body: JSON.stringify({
                  "status": "Sign SUCCESS",
              }),
          });
          if (recordResponse.status > 300)
              throw new Error("Failed to modify record entry " + JSON.stringify(recordResponse.body));
          //END modify record entry in eID server
          return {
              action: Action$1.SIGN_SUCCESS,
              response: {
                  ...pick(signatureVerifyResponse, [
                      "body",
                      "headers",
                      "ok",
                      "redirected",
                      "status",
                      "statusText",
                      "type",
                      "url",
                  ]),
              },
          };
      }
      catch (error) {
          console.error("Sign:", error);
          return {
              action: Action$1.SIGN_FAILURE,
              error: serializeError(error),
          };
      }
      finally {
          if (nativeAppService)
              nativeAppService.close();
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  async function getStatus() {
      const extension = config.VERSION;
      try {
          const nativeAppService = new NativeAppService();
          const status = await nativeAppService.connect();
          const nativeApp = (status.version.startsWith("v")
              ? status.version.substring(1)
              : status.version);
          nativeAppService.close();
          return {
              extension,
              nativeApp,
              action: Action$1.STATUS_SUCCESS,
          };
      }
      catch (error) {
          error.extension = extension;
          console.error("Status:", error);
          return {
              action: Action$1.STATUS_FAILURE,
              error: serializeError(error),
          };
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  function tokenSigningResponse(result, nonce, optional) {
      const response = {
          nonce,
          result,
          src: "background.js",
          extension: config.VERSION,
          isWebeid: true,
          ...(optional ? optional : {}),
      };
      return response;
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  function errorToResponse(nonce, error) {
      if (error.code === ErrorCode$1.ERR_WEBEID_USER_CANCELLED) {
          return tokenSigningResponse("user_cancel", nonce);
      }
      else if (error.code === ErrorCode$1.ERR_WEBEID_NATIVE_FATAL) {
          const nativeException = serializeError(error);
          return tokenSigningResponse("driver_error", nonce, { nativeException });
      }
      else {
          return tokenSigningResponse("technical_error", nonce, { error });
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  async function getStatus$1(nonce) {
      try {
          const nativeAppService = new NativeAppService();
          const nativeAppStatus = await nativeAppService.connect();
          // The token-signing uses x.y.z.build version string pattern
          const version = nativeAppStatus.version.replace("+", ".");
          if (!version) {
              throw new Error("missing native application version");
          }
          return tokenSigningResponse("ok", nonce, { version });
      }
      catch (error) {
          console.error(error);
          return errorToResponse(nonce, error);
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  async function getCertificate(nonce, sourceUrl, lang, filter = "SIGN") {
      try {
          const nativeAppService = new NativeAppService();
          const nativeAppStatus = await nativeAppService.connect();
          console.log("Get certificate: connected to native", nativeAppStatus);
          const certificateResponse = await Promise.race([
              nativeAppService.send({
                  command: "get-certificate",
                  arguments: {
                      "type": filter.toLowerCase(),
                      "origin": (new URL(sourceUrl)).origin,
                  },
              }),
              throwAfterTimeout(config.TOKEN_SIGNING_USER_INTERACTION_TIMEOUT, new UserTimeoutError()),
          ]);
          if (!certificateResponse.certificate) {
              return tokenSigningResponse("no_certificates", nonce);
          }
          else {
              return tokenSigningResponse("ok", nonce, {
                  cert: new ByteArray().fromBase64(certificateResponse.certificate).toHex(),
              });
          }
      }
      catch (error) {
          console.error(error);
          return errorToResponse(nonce, error);
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  async function sign$1(nonce, sourceUrl, certificate, hash, algorithm, lang) {
      try {
          const nativeAppService = new NativeAppService();
          const nativeAppStatus = await nativeAppService.connect();
          console.log("Sign: connected to native", nativeAppStatus);
          const signatureResponse = await Promise.race([
              nativeAppService.send({
                  command: "sign",
                  arguments: {
                      "doc-hash": new ByteArray().fromHex(hash).toBase64(),
                      "hash-algo": algorithm,
                      "origin": (new URL(sourceUrl)).origin,
                      "user-eid-cert": new ByteArray().fromHex(certificate).toBase64(),
                  },
              }),
              throwAfterTimeout(config.TOKEN_SIGNING_USER_INTERACTION_TIMEOUT, new UserTimeoutError()),
          ]);
          if (!signatureResponse.signature) {
              return tokenSigningResponse("technical_error", nonce);
          }
          else {
              return tokenSigningResponse("ok", nonce, {
                  signature: new ByteArray().fromBase64(signatureResponse.signature).toHex(),
              });
          }
      }
      catch (error) {
          console.error(error);
          return errorToResponse(nonce, error);
      }
  }

  /*
   * Copyright (c) 2020 The Web eID Project
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   */
  var TokenSigningAction = {
      getStatus: getStatus$1,
      getCertificate,
      sign: sign$1,
  };

  async function onAction(message) {
      switch (message.action) {
          case Action$1.AUTHENTICATE:
              return await authenticate(message.getAuthChallengeUrl, message.postAuthTokenUrl, message.headers, message.userInteractionTimeout || libraryConfig.DEFAULT_USER_INTERACTION_TIMEOUT, message.serverRequestTimeout || libraryConfig.DEFAULT_SERVER_REQUEST_TIMEOUT);
          case Action$1.SIGN:
              return await sign(message.postPrepareSigningUrl, message.postFinalizeSigningUrl, message.headers, message.userInteractionTimeout || libraryConfig.DEFAULT_USER_INTERACTION_TIMEOUT, message.serverRequestTimeout || libraryConfig.DEFAULT_SERVER_REQUEST_TIMEOUT);
          case Action$1.STATUS:
              return await getStatus();
      }
  }
  async function onTokenSigningAction(message, sender) {
      if (!sender.url)
          return;
      switch (message.type) {
          case "VERSION": {
              return await TokenSigningAction.getStatus(message.nonce);
          }
          case "CERT": {
              return await TokenSigningAction.getCertificate(message.nonce, sender.url, message.lang, message.filter);
          }
          case "SIGN": {
              return await TokenSigningAction.sign(message.nonce, sender.url, message.cert, message.hash, message.hashtype, message.lang);
          }
      }
  }
  browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
      console.log("Received");
      if (message.action) {
          onAction(message).then(sendResponse);
      }
      else if (message.type) {
          onTokenSigningAction(message, sender).then(sendResponse);
      }
      else {
          console.log("Message not supported");
      }
      return true;
  });
  //probar conexion
  console.log("started");

}());
//# sourceMappingURL=background.js.map
